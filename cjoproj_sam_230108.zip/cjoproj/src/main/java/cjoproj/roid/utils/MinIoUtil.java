package cjoproj.roid.utils;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.Base64;

import javax.imageio.ImageIO;

import org.apache.commons.io.FileUtils;

public class MinIoUtil {

	public String fileToBase64StringConversion(String inFilePath) throws IOException {
		
		// load file from /src/test/resources
		ClassLoader classLoader = getClass().getClassLoader();
		File inputFile = new File(classLoader.getResource(inFilePath).getFile());

		byte[] fileContent = FileUtils.readFileToByteArray(inputFile);
		String encodedString = Base64.getEncoder().encodeToString(fileContent);

		return encodedString;
		
//		// create output file
//		File outputFile = new File(inputFile.getParentFile().getAbsolutePath() + File.pathSeparator + outputFilePath);
//
//		// decode the string and write to file
//		byte[] decodedBytes = Base64.getDecoder().decode(encodedString);
//		FileUtils.writeByteArrayToFile(outputFile, decodedBytes);
		
	}

	public BufferedImage convBase64ToImage(String src) throws IOException {
		byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(src);

		return ImageIO.read(new ByteArrayInputStream(imageBytes));
	}

	
	
	public static void main(String[] args) {


		
		
	}

}
